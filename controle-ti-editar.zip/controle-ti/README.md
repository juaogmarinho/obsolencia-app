# Controle de TI (entregas, estoque e envios)

O estoque aceita notebooks e monitores, com listas de modelos configuráveis pelo administrador. Use **Entregar** em um item do estoque para abrir os dados do colaborador e transferi-lo para Entregas; a operação remove o item do estoque e cria o registro de entrega em uma única transação. A página **Manutenção** registra equipamentos e chamados da autorizada. **Demandas** oferece um quadro com as etapas A fazer, Em andamento, Aguardando e Concluída; mova os cartões entre colunas para atualizar a etapa.

## Subir com Docker (Windows)
1. Instale o Docker Desktop (com WSL2) e abra-o.
2. Nesta pasta: `docker compose up -d --build`
3. Acesse `http://localhost:3001`. Na rede: `http://IP-DO-NOTEBOOK:3001`.
4. A **primeira conta criada vira Administrador**. Os cadastros seguintes ficam pendentes e não podem entrar até um Administrador ou Supervisor aprová-los na aba **Aprovações**. Ao criar a conta, selecione o local de trabalho. O administrador pode alterar local e perfil na aba **Usuários**.
5. Libere a porta (PowerShell como administrador):
   `New-NetFirewallRule -DisplayName "Controle TI" -Direction Inbound -Protocol TCP -LocalPort 3001 -Action Allow`
6. Reserve um IP fixo para o notebook no DHCP e impeça a suspensão do Windows.

## Localidades e perfis
- Localidades disponíveis: Recife, Sobradinho, Paulo Afonso, Salvador, Natal, Teresina e Fortaleza.
- Operadores e visualizadores consultam e compartilham os registros da própria localidade. Operadores também cadastram e editam esses dados.
- Supervisor/Gestor tem acesso de leitura às localidades selecionadas ou a todas, no Dashboard, Estoque, Manutenção, Demandas e Entregas.
- Administradores e Supervisores podem aprovar ou recusar novos cadastros. Somente um Administrador pode aprovar uma conta com perfil de Administrador.
- Administradores veem e administram todas as localidades. Nas listas e no Dashboard, use o filtro **Todas as localidades** para alternar a visão geral e a visão de cada unidade.
- Contas antigas sem localidade precisam ser atualizadas em **Usuários** pelo administrador antes de poderem consultar dados. Registros antigos são associados ao local do usuário que os cadastrou quando o administrador atribui essa localidade; também é possível corrigir o local de um registro ao editá-lo.
- visualizador: somente consulta · operador: consulta, cadastra e edita na própria localidade · supervisor/gestor: consulta os locais escolhidos · admin: tudo, inclusive exclusões e gerenciamento de usuários.

## Ajustes (docker-compose.yml)
- `DOMINIO=empresa.com.br` aceita cadastro só de e-mails desse domínio.
- `PERFIL_PADRAO=operador` muda o perfil inicial dos novos cadastros.

## Configurações do sistema
- Administradores podem personalizar nome e logotipo, tema, 12 cores de destaque, densidade, formato dos cantos, contraste, modelos e status.
- Em **Formulários**, é possível renomear e excluir campos opcionais, além de criar até 15 campos adicionais por área (Entregas, Estoque, Envios, Manutenção e Demandas). Campos obrigatórios e de etapa/status não podem ser excluídos. A exclusão remove o campo da interface e das exportações, mas preserva os valores já registrados, que deixam de ser exibidos.
- Campos excluídos podem ser recuperados nas configurações; campos personalizados podem ser removidos definitivamente para liberar espaço no limite de 15.
- Use as setas ao lado de cada campo para ajustar a ordem no formulário e nas colunas correspondentes das listas. Nas listas, selecione um cabeçalho para ordenar os registros.
- Cada usuário pode manter preferências próprias em **Personalizar** ou escolher o padrão da organização para tema, cor, densidade, cantos e contraste.
- Os formulários agrupam campos por assunto, apontam erros junto aos campos obrigatórios e avisam antes de descartar alterações. O Dashboard mantém os indicadores e gráficos operacionais anteriores.

## Gestão de ativos de TI
- O fluxo operacional usa **Estoque** e **Entregas**. Ao marcar uma entrega como concluída, o sistema gera o termo em PDF no formato do modelo fornecido: dados do solicitante e equipamento, acessórios, movimentação, observações, cláusulas e campos de assinatura do colaborador e do técnico.
- Os dados adicionais do termo (matrícula, VP, UO, empresa, localização e gestor) podem ser preenchidos na entrega; o PDF indica quando um dado não foi informado. Entregas concluídas e devoluções permitem baixar o termo novamente.
- A página dedicada **Chamados** foi retirada da navegação. Os dados e recursos de chamados existentes são preservados para manter compatibilidade com os registros de manutenção.
- Em **Relatórios**, exporte inventário, categorias abaixo do estoque mínimo, entregas/devoluções por período e manutenções em CSV, Excel ou PDF. Administradores podem ajustar o mínimo de cada categoria (padrão inicial: 2).
- Operadores consultam e movimentam entregas de sua localidade; visualizadores têm leitura; Supervisores têm leitura entre localidades; Administradores gerenciam todas as unidades.

## Atualização e persistência de dados
- Na primeira inicialização da nova versão, tabelas próprias de ITAM são criadas e estoque, entregas e registros do módulo antigo de Manutenção são importados de forma idempotente. Chamados antigos mantêm observações e, quando possível, são associados ao ativo pelo patrimônio ou número de série. Os registros de origem permanecem intactos.
- A base permanece em `./data/controle.db`; anexos protegidos ficam em `./data/uploads`. Inclua ambos no backup regular e mantenha o volume `./data` ao atualizar.
- Tendências percentuais ficam indisponíveis até existir um snapshot do período comparável; o sistema não inventa variações antes desse histórico.

## Backup e atualização
- Os dados ficam em `./data/controle.db` (inclui a tabela `historico` com quem alterou o quê); evidências anexadas ficam em `./data/uploads`. Copie os dois regularmente (de preferência com o contêiner parado).
- Atualizar: `docker compose up -d --build` (os dados permanecem).
- Sem HTTPS as senhas trafegam sem criptografia na rede interna; use um proxy reverso (Caddy/Nginx) se a política da empresa exigir.
