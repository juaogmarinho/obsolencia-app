const ITAM = {
  assets: { items: [], total: 0, page: 1, pages: 0 },
  tickets: { items: [], total: 0, page: 1, pages: 0 },
  dashboard: null,
  thresholds: [],
  query: '',
  status: '',
  category: '',
  report: 'assets',
  activeAsset: null,
  activeTicket: null
};

T.ativos = { n: 'Ativos' };
T.relatorios = { n: 'Relatórios' };
IC.ativos = '<path d="M3 7l9-4 9 4-9 4-9-4zM3 7v10l9 4 9-4V7"/>';
IC.relatorios = '<path d="M5 3h10l4 4v14H5zM15 3v5h5"/><path d="M8 13h8M8 17h8"/>';
D.ativos = [];
D.relatorios = [];
const ITAM_CATEGORIES = {
  notebook: 'Notebook', monitor: 'Monitor', headset: 'Headset', mouse: 'Mouse',
  keyboard: 'Teclado', backpack: 'Mochila', other: 'Outros'
};
const ITAM_STATUSES = {
  available: 'Disponível', reserved: 'Reservado', delivered: 'Entregue',
  maintenance: 'Em manutenção', lost: 'Perdido', retired: 'Baixado'
};
const ITAM_TICKET_STATUSES = {
  open: 'Aberto', in_progress: 'Em andamento', waiting_parts: 'Aguardando peça',
  completed: 'Concluído', cancelled: 'Cancelado'
};
const ITAM_PRIORITIES = { critical: 'Crítica', high: 'Alta', normal: 'Normal', low: 'Baixa' };
const ITAM_COLORS = ['#0b7a8a','#2563eb','#7c3aed','#d97706','#16a34a','#db2777','#64748b'];
const itamQueryString = values => Object.entries(values).filter(([,value]) => value !== '' && value != null)
  .map(([key,value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`).join('&');
const itamLocationParam = () => canViewAll() && selectedLocation !== '*' ? selectedLocation : '';
const itamDate = value => {
  if (!value) return '—';
  const date = typeof value === 'number' ? new Date(value) : new Date(`${String(value).slice(0,10)}T00:00:00`);
  return Number.isNaN(date.getTime()) ? '—' : date.toLocaleDateString('pt-BR');
};
const itamDateTime = value => value ? new Date(Number(value)).toLocaleString('pt-BR') : '—';
const itamPill = (text, tone='') => `<span class="itam-pill ${tone}">${e(text)}</span>`;
const itamField = (label,id,value='',type='text',extra='') => `<div class="itam-field"><label for="${id}">${e(label)}</label><input id="${id}" type="${type}" value="${e(value)}" ${extra}></div>`;
const itamSelect = (label,id,options,value='') => `<div class="itam-field"><label for="${id}">${e(label)}</label><select id="${id}">${options.map(([key,title])=>`<option value="${e(key)}" ${key===value?'selected':''}>${e(title)}</option>`).join('')}</select></div>`;
const itamTextArea = (label,id,value='',rows=3) => `<div class="itam-field full"><label for="${id}">${e(label)}</label><textarea id="${id}" rows="${rows}">${e(value)}</textarea></div>`;
const itamLocalField = (label,id,value) => `<div class="itam-field"><label for="${id}">${e(label)}</label><select id="${id}">${LOCATIONS.map(name=>`<option value="${e(name)}" ${name===value?'selected':''}>${e(name)}</option>`).join('')}</select></div>`;

async function loadItamAssets(page=ITAM.assets.page) {
  const query = itamQueryString({
    page, pageSize: 50, location: itamLocationParam(),
    q: ITAM.query, status: Object.prototype.hasOwnProperty.call(ITAM_STATUSES,ITAM.status)?ITAM.status:'', category: ITAM.category
  });
  ITAM.assets = await api('GET', `/api/assets?${query}`);
  D.ativos = ITAM.assets.items;
  if (tab === 'ativos') renderItam();
  return ITAM.assets;
}

async function loadItamTickets(page=ITAM.tickets.page) {
  const query = itamQueryString({
    page, pageSize: 25, location: itamLocationParam(),
    q: ITAM.query, status: Object.prototype.hasOwnProperty.call(ITAM_TICKET_STATUSES,ITAM.status)?ITAM.status:''
  });
  ITAM.tickets = await api('GET', `/api/maintenance?${query}`);
  return ITAM.tickets;
}

async function loadItamDashboard() {
  const query = itamQueryString({ location: itamLocationParam() });
  ITAM.dashboard = await api('GET', `/api/dashboard?${query}`);
  if (tab === 'dashboard') renderItamDashboard();
  return ITAM.dashboard;
}

async function loadStockThresholds() {
  ITAM.thresholds = await api('GET', '/api/stock-thresholds');
  if (tab === 'relatorios') renderItam();
  return ITAM.thresholds;
}

function itamPager(group, key) {
  const data = ITAM[group];
  if (data.pages <= 1) return `<div class="itam-pages"><span>${data.total} registros</span></div>`;
  return `<div class="itam-pages"><span>${data.total} registros · página ${data.page} de ${data.pages}</span><span>
    <button type="button" data-page="${data.page-1}" data-page-kind="${key}" ${data.page<=1?'disabled':''}>Anterior</button>
    <button type="button" data-page="${data.page+1}" data-page-kind="${key}" ${data.page>=data.pages?'disabled':''}>Próxima</button>
  </span></div>`;
}

function itamAssetRows() {
  const items = ITAM.assets.items;
  if (!items.length) return '<tr><td class="empty" colspan="8">Nenhum ativo encontrado para os filtros atuais.</td></tr>';
  return items.map(asset => {
    const tone = ['maintenance','lost','retired'].includes(asset.status) ? 'bad' : ['reserved','delivered'].includes(asset.status) ? 'warn' : 'good';
    const actions = [
      `<button type="button" data-asset-action="history" data-id="${e(asset.id)}">Histórico</button>`,
      canEdit() ? `<button type="button" data-asset-action="edit" data-id="${e(asset.id)}">Editar</button>` : ''
    ];
    if (canEdit() && ['available','reserved'].includes(asset.status)) actions.push(`<button type="button" data-asset-action="assign" data-id="${e(asset.id)}">Entregar</button>`);
    if (canEdit() && asset.status === 'delivered') actions.push(`<button type="button" data-asset-action="return" data-id="${e(asset.id)}">Devolver</button>`);
    if (canEdit() && !['delivered','maintenance'].includes(asset.status)) actions.push(`<button type="button" data-asset-action="status" data-id="${e(asset.id)}">Status</button>`);
    if (canEdit() && !['maintenance','lost','retired'].includes(asset.status)) actions.push(`<button type="button" data-asset-action="maintenance" data-id="${e(asset.id)}">Manutenção</button>`);
    if (me.role === 'admin' && !['delivered','maintenance'].includes(asset.status)) actions.push(`<button type="button" data-asset-action="delete" data-id="${e(asset.id)}">Excluir</button>`);
    return `<tr><td><b>${e(asset.patrimonio||'Sem patrimônio')}</b><small class="itam-muted" style="display:block">${e(asset.serial_number||'')}</small></td>
      <td>${e(ITAM_CATEGORIES[asset.category]||asset.category)}</td><td>${e([asset.manufacturer,asset.model].filter(Boolean).join(' ')||'—')}</td>
      <td>${itamPill(ITAM_STATUSES[asset.status]||asset.status,tone)}</td><td>${e(asset.location)}</td>
      <td>${e(asset.activeAssignment?.holder_name||'—')}</td><td>${itamDate(asset.warranty_until)}</td>
      <td><span class="itam-actions">${actions.join('')}</span></td></tr>`;
  }).join('');
}

function itamTicketRows() {
  const items = ITAM.tickets.items;
  if (!items.length) return '<tr><td class="empty" colspan="8">Nenhum chamado encontrado para os filtros atuais.</td></tr>';
  return items.map(ticket => {
    const overdue = !['completed','cancelled'].includes(ticket.status) && Number(ticket.sla_due_at) < Date.now();
    return `<tr><td><b>${e(ticket.title)}</b><small class="itam-muted" style="display:block">${e(ticket.patrimonio||ticket.model||'Sem ativo vinculado')}</small></td>
      <td>${itamPill(ITAM_PRIORITIES[ticket.priority]||ticket.priority,ticket.priority==='critical'?'bad':'')}</td>
      <td>${itamPill(ITAM_TICKET_STATUSES[ticket.status]||ticket.status,['completed','cancelled'].includes(ticket.status)?'good':'warn')}</td>
      <td>${e(ticket.technician||'—')}</td><td>${e(ticket.location)}</td>
      <td class="${overdue?'low':''}">${itamDateTime(ticket.sla_due_at)}${overdue?' · Atrasado':''}</td>
      <td>${itamDate(ticket.expected_at)}</td><td><span class="itam-actions"><button type="button" data-ticket-action="open" data-id="${e(ticket.id)}">Detalhes</button>
      ${canEdit()?`<button type="button" data-ticket-action="edit" data-id="${e(ticket.id)}">Atualizar</button>`:''}</span></td></tr>`;
  }).join('');
}

function renderItam() {
  const area = $('itam-area');
  if (tab === 'ativos') {
    area.innerHTML = `<div class="itam-toolbar">
      <input id="itamQuery" type="search" value="${e(ITAM.query)}" placeholder="Patrimônio, série, modelo…">
      <select id="itamStatus"><option value="">Todos os status</option>${Object.entries(ITAM_STATUSES).map(([key,label])=>`<option value="${key}" ${key===ITAM.status?'selected':''}>${label}</option>`).join('')}</select>
      <select id="itamCategory"><option value="">Todas as categorias</option>${Object.entries(ITAM_CATEGORIES).map(([key,label])=>`<option value="${key}" ${key===ITAM.category?'selected':''}>${label}</option>`).join('')}</select>
      <span class="spacer"></span><button type="button" data-itam-refresh="assets">Atualizar</button>
      ${canEdit()?'<button type="button" class="p" data-itam-create="asset">Cadastrar ativo</button>':''}</div>
      <div class="itam-table-wrap"><table class="itam-table"><thead><tr><th>Patrimônio / Série</th><th>Categoria</th><th>Fabricante / Modelo</th><th>Status</th><th>Localidade</th><th>Responsável</th><th>Garantia</th><th>Ações</th></tr></thead><tbody>${itamAssetRows()}</tbody></table></div>
      ${itamPager('assets','assets')}`;
  } else renderItamReports();
}

function renderItamReports() {
  const canConfigure = me.role === 'admin';
  $('itam-area').innerHTML = `<section class="itam-card"><h2>Relatórios</h2><p class="itam-muted">Exporte inventário, estoque crítico, entregas e manutenções em CSV, Excel ou PDF.</p>
    <div class="itam-report-grid">
      ${itamSelect('Relatório','reportKind',[
        ['assets','Inventário completo'],['stock-critical','Estoque crítico'],['deliveries','Entregas e devoluções'],['maintenance','Manutenção']
      ],ITAM.report)}
      ${itamSelect('Formato','reportFormat',[['csv','CSV'],['xlsx','Excel (.xlsx)'],['pdf','PDF']],'csv')}
      <div class="itam-field"><label for="reportFrom">De (entregas)</label><input id="reportFrom" type="date"></div>
      <div class="itam-field"><label for="reportTo">Até (entregas)</label><input id="reportTo" type="date"></div>
    </div><div style="margin-top:14px"><button type="button" class="p" data-report-download="1">Baixar relatório</button></div></section>
    ${canConfigure?`<section class="itam-card"><h2>Estoque mínimo por categoria</h2><p class="itam-muted">Categorias abaixo do limite aparecem no indicador de estoque crítico.</p>
      <div class="itam-report-grid">${ITAM.thresholds.map(item=>`<div class="itam-field"><label for="threshold-${e(item.category)}">${e(ITAM_CATEGORIES[item.category]||item.category)}</label>
      <input id="threshold-${e(item.category)}" type="number" min="0" max="10000" step="1" value="${item.minimum}"></div>`).join('')}</div>
      <div style="margin-top:14px"><button type="button" class="p" data-save-thresholds="1">Salvar limites</button></div></section>`:''}`;
}

function renderItamDashboard() {
  const data = ITAM.dashboard;
  if (!data) {
    $('dash').innerHTML = '<div class="itam-card"><h2>Carregando indicadores…</h2></div>';
    return;
  }
  const cards = data.cards.map(card => {
    const value = card.value == null ? '—' : card.metric === 'slaPercent' ? `${card.value}%` : Number(card.value).toLocaleString('pt-BR');
    let change = card.changePercent == null ? 'Comparativo mensal indisponível' : `${card.changePercent>0?'+':''}${card.changePercent}% em relação ao mês anterior`;
    return `<article class="itam-metric" style="--metric:${e(card.color)}" title="${e(card.tooltip)}">
      <button type="button" data-metric="${e(card.metric)}" aria-label="${e(card.title)}: ${e(value)}"><strong>${e(value)}</strong><span>${e(card.title)}</span></button><small>${e(change)}</small></article>`;
  }).join('');
  const categories = data.charts.categories, total = categories.reduce((sum,row)=>sum+row.value,0);
  let cursor = 0;
  const slices = categories.map((row,index)=>{
    const start = total ? cursor / total * 100 : 0;
    cursor += row.value;
    const end = total ? cursor / total * 100 : 100;
    return `${ITAM_COLORS[index%ITAM_COLORS.length]} ${start}% ${end}%`;
  }).join(',');
  const legend = categories.map((row,index)=>`<span style="--c:${ITAM_COLORS[index%ITAM_COLORS.length]}">${e(ITAM_CATEGORIES[row.category]||row.category)} · ${row.value}</span>`).join('');
  const maxStatus = Math.max(1,...data.charts.statuses.map(item=>item.value));
  const statusChart = data.charts.statuses.map(item=>`<div class="itam-bar"><span>${e(ITAM_STATUSES[item.status]||item.status)}</span><i style="--w:${item.value/maxStatus*100}%"></i><b>${item.value}</b></div>`).join('');
  const movements = data.charts.movements, maxMovement = Math.max(1,...movements.flatMap(row=>[row.deliveries,row.returns,row.maintenance]));
  const x = index => 34 + index * 47.8, y = value => 178 - value / maxMovement * 140;
  const line = key => movements.map((row,index)=>`${x(index)},${y(row[key])}`).join(' ');
  const monthLabels = movements.map((row,index)=>index%2===0?`<text x="${x(index)}" y="202" text-anchor="middle">${e(row.month.slice(5))}</text>`:'').join('');
  const movementChart = `<svg class="itam-chart" viewBox="0 0 600 220" role="img" aria-label="Movimentações dos últimos 12 meses">
    <line x1="30" y1="178" x2="585" y2="178" stroke="var(--bd)"/><polyline fill="none" stroke="#0b7a8a" stroke-width="3" points="${line('deliveries')}"/>
    <polyline fill="none" stroke="#2563eb" stroke-width="3" points="${line('returns')}"/><polyline fill="none" stroke="#d97706" stroke-width="3" points="${line('maintenance')}"/>${monthLabels}</svg>
    <div class="itam-legend"><span style="--c:#0b7a8a">Entregas</span><span style="--c:#2563eb">Devoluções</span><span style="--c:#d97706">Manutenções</span></div>`;
  const top = data.charts.topEquipment.length ? data.charts.topEquipment.map((item,index)=>`<div class="itam-stock-row"><b>${index+1}. ${e(ITAM_CATEGORIES[item.category]||item.category)}</b><span>${e([item.manufacturer,item.model].filter(Boolean).join(' ')||'Modelo não informado')}</span><strong>${item.distributions}</strong></div>`).join('') : '<p class="itam-muted">Ainda não há entregas para classificar.</p>';
  const cities = data.charts.cities.length ? data.charts.cities.map(item=>`<div class="itam-bar"><span>${e(item.location)}</span><i style="--w:${item.count/Math.max(1,...data.charts.cities.map(row=>row.count))*100}%"></i><b>${item.count}</b></div>`).join('') : '<p class="itam-muted">Nenhum ativo entregue no momento.</p>';
  const quick = `<div class="itam-toolbar"><button type="button" data-dash-itam="ativos">Ver ativos</button><button type="button" data-dash-itam="relatorios">Relatórios</button>
    ${canEdit()?'<button type="button" class="p" data-itam-create="asset">Cadastrar ativo</button>':''}</div>`;
  $('dash').innerHTML = `${quick}<div class="itam-metrics">${cards}</div><div class="itam-grid">
    <section class="itam-card"><h2>Estoque por categoria</h2>${total?`<div class="itam-donut" role="img" aria-label="Distribuição por categoria" style="--segments:${slices}"></div>`:'<p class="itam-muted">Sem ativos cadastrados.</p>'}<div class="itam-legend">${legend}</div></section>
    <section class="itam-card"><h2>Movimentação mensal · 12 meses</h2>${movementChart}</section>
    <section class="itam-card"><h2>Status dos ativos</h2><div class="itam-bars">${statusChart}</div></section>
    <section class="itam-card"><h2>Equipamentos mais distribuídos</h2>${top}</section>
    <section class="itam-card"><h2>Ativos entregues por localidade</h2><div class="itam-bars">${cities}</div></section>
  </div>`;
}

function itamModal(title,content,{save=true,deleteButton=false,saveLabel='Salvar'}={}) {
  $('itamTitle').textContent=title;
  $('itamForm').innerHTML=content;
  $('itamSave').style.display=save?'':'none';
  $('itamSave').textContent=saveLabel;
  $('itamDelete').style.display=deleteButton?'':'none';
  $('itamDelete').onclick=null;
  $('itamSave').onclick=null;
  if(!$('itamDlg').open)$('itamDlg').showModal();
}

function itamOpenAssetForm(asset=null) {
  ITAM.activeAsset=asset;
  const categories=Object.entries(ITAM_CATEGORIES);
  const conditions=[['new','Novo'],['excellent','Excelente'],['good','Bom'],['fair','Regular'],['damaged','Danificado']];
  const data=asset||{};
  const content=`<div class="itam-form-grid">
    ${itamField('Patrimônio','assetPatrimonio',data.patrimonio||'')}
    ${itamField('Número de série','assetSerial',data.serial_number||'')}
    ${itamField('Fabricante','assetManufacturer',data.manufacturer||'')}
    ${itamField('Modelo *','assetModel',data.model||'')}
    ${itamSelect('Categoria *','assetCategory',categories,data.category||'notebook')}
    ${itamField('Centro de custo','assetCostCenter',data.cost_center||'')}
    ${itamField('Data de aquisição','assetAcquired',data.acquired_at||'','date')}
    ${itamField('Valor de compra','assetValue',data.purchase_value??'','number','min="0" step="0.01"')}
    ${itamField('Garantia até','assetWarranty',data.warranty_until||'','date')}
    ${itamField('Nota fiscal','assetInvoice',data.invoice_number||'')}
    ${itamSelect('Estado do equipamento','assetCondition',conditions,data.condition||'good')}
    ${me.role==='admin'?itamLocalField('Localidade','assetLocation',data.location||selectedLocation!=='*'?selectedLocation:LOCATIONS[0]):''}
  </div>`;
  itamModal(asset?'Editar ativo':'Cadastrar ativo',content);
  if(me.role==='admin'&&asset)$('assetLocation').value=asset.location;
  $('itamSave').onclick=async()=>{
    const body={
      patrimonio:$('assetPatrimonio').value,serial_number:$('assetSerial').value,
      manufacturer:$('assetManufacturer').value,model:$('assetModel').value,
      category:$('assetCategory').value,cost_center:$('assetCostCenter').value,
      acquired_at:$('assetAcquired').value||null,purchase_value:$('assetValue').value,
      warranty_until:$('assetWarranty').value||null,invoice_number:$('assetInvoice').value,
      condition:$('assetCondition').value,status:asset?.status||'available',
      location:me.role==='admin'?$('assetLocation').value:me.localidade
    };
    if(asset)body.version=asset.version;
    try {
      await api(asset?'PUT':'POST',asset?`/api/assets/${encodeURIComponent(asset.id)}`:'/api/assets',body);
      $('itamDlg').close();await Promise.all([loadItamAssets(ITAM.assets.page),loadItamDashboard()]);toast(asset?'Ativo atualizado':'Ativo cadastrado');
    } catch(error) { alert(`Não foi possível salvar o ativo: ${error.message}`); }
  };
}

let itamSearchTimer=null;
$('itam-area').addEventListener('input',event=>{
  if(event.target.id==='itamQuery') {
    ITAM.query=event.target.value.trim();
    clearTimeout(itamSearchTimer);
    itamSearchTimer=setTimeout(()=>tab==='ativos'?loadItamAssets(1).catch(itamError):null,300);
  }
});
$('itam-area').addEventListener('change',event=>{
  if(event.target.id==='itamStatus'){ITAM.status=event.target.value;if(tab==='ativos')loadItamAssets(1).catch(itamError)}
  if(event.target.id==='itamCategory'){ITAM.category=event.target.value;loadItamAssets(1).catch(itamError)}
  if(event.target.id==='reportKind'){ITAM.report=event.target.value;renderItamReports()}
});
$('itam-area').addEventListener('click',async event=>{
  const button=event.target.closest('button');
  if(!button)return;
  if(button.dataset.pageKind==='assets')return loadItamAssets(+button.dataset.page).catch(itamError);
  if(button.dataset.pageKind==='tickets')return loadItamTickets(+button.dataset.page).catch(itamError);
  if(button.dataset.itamRefresh==='assets')return loadItamAssets(ITAM.assets.page).catch(itamError);
  if(button.dataset.itamRefresh==='tickets')return loadItamTickets(ITAM.tickets.page).catch(itamError);
  if(button.dataset.itamCreate==='asset')return itamOpenAssetForm();
  if(button.dataset.itamCreate==='ticket')return itamOpenTicket(null,{create:true});
  if(button.dataset.reportDownload) {
    const query=itamQueryString({location:itamLocationParam(),from:$('reportFrom').value,to:$('reportTo').value});
    const link=document.createElement('a');link.href=`/api/reports/${encodeURIComponent(ITAM.report)}/${encodeURIComponent($('reportFormat').value)}?${query}`;link.click();return;
  }
  if(button.dataset.saveThresholds) {
    const items=ITAM.thresholds.map(item=>({category:item.category,minimum:Number($(`threshold-${item.category}`).value)}));
    if(items.some(item=>!Number.isInteger(item.minimum)||item.minimum<0||item.minimum>10000)){alert('Use limites inteiros entre 0 e 10000.');return}
    try{ITAM.thresholds=await api('PUT','/api/stock-thresholds',{items});await loadItamDashboard();renderItamReports();toast('Limites de estoque atualizados')}
    catch(error){alert(`Não foi possível salvar os limites: ${error.message}`)}
    return;
  }
  if(button.dataset.dashItam){tab=button.dataset.dashItam;ITAM.query='';ITAM.status='';ITAM.category='';render();if(tab==='ativos')loadItamAssets(1).catch(itamError);return}
  if(button.dataset.metric) {
    if(button.dataset.metric==='stockCritical'){tab='relatorios';ITAM.report='stock-critical';render();return}
    if(button.dataset.metric==='openTickets')return;
    tab='ativos';ITAM.status=button.dataset.metric==='maintenance'?'maintenance':button.dataset.metric==='delivered'?'delivered':button.dataset.metric==='available'?'available':'';
    render();if(tab==='ativos')loadItamAssets(1).catch(itamError);else loadItamTickets(1).catch(itamError);return;
  }
  if(button.dataset.assetAction) {
    const asset=ITAM.assets.items.find(item=>item.id===button.dataset.id);
    if(!asset)return;
    if(button.dataset.assetAction==='history')return itamOpenHistory(asset.id);
    if(button.dataset.assetAction==='edit')return itamOpenAssetForm(asset);
    if(button.dataset.assetAction==='assign')return itamOpenAssign(asset);
    if(button.dataset.assetAction==='return')return itamReturnAsset(asset);
    if(button.dataset.assetAction==='status')return itamChangeAssetStatus(asset);
    if(button.dataset.assetAction==='maintenance')return itamOpenTicket(null,{create:true,assetId:asset.id});
    if(button.dataset.assetAction==='delete') {
      if(!confirm(`Remover ${asset.patrimonio||asset.model} da visualização? O histórico será preservado.`))return;
      try{await api('DELETE',`/api/assets/${encodeURIComponent(asset.id)}`,{version:asset.version});await Promise.all([loadItamAssets(ITAM.assets.page),loadItamDashboard()]);toast('Ativo removido logicamente')}
      catch(error){alert(`Não foi possível remover o ativo: ${error.message}`)}
    }
    return;
  }
  if(button.dataset.ticketAction) {
    const ticket=ITAM.tickets.items.find(item=>item.id===button.dataset.id);
    if(ticket)return itamOpenTicket(ticket);
  }
});

$('itamDlg').addEventListener('click',async event=>{
  const button=event.target.closest('button');
  if(!button)return;
  if(button.dataset.term) {
    const link=document.createElement('a');link.href=`/api/assignments/${encodeURIComponent(button.dataset.term)}/term.pdf`;link.target='_blank';link.rel='noopener';link.click();
  }
  if(button.dataset.ticketActivity) {
    const ticket=ITAM.activeTicket,note=$('ticketActivity')?.value.trim();
    if(!ticket||!note){$('ticketActivity')?.focus();return}
    try{await api('POST',`/api/maintenance/${encodeURIComponent(ticket.id)}/activities`,{note});await itamOpenTicket(ticket.id)}
    catch(error){alert(`Não foi possível registrar a atividade: ${error.message}`)}
  }
  if(button.dataset.ticketUpload) {
    const ticket=ITAM.activeTicket,file=$('ticketFile')?.files?.[0];
    if(!ticket||!file){$('ticketFile')?.focus();return}
    const body=new FormData();body.append('file',file);
    try{
      const response=await fetch(`/api/maintenance/${encodeURIComponent(ticket.id)}/attachments`,{method:'POST',body});
      const result=await response.json().catch(()=>({}));
      if(!response.ok)throw new Error(result.erro||`Erro ${response.status}`);
      await itamOpenTicket(ticket.id);toast('Anexo enviado');
    }catch(error){alert(`Não foi possível enviar o anexo: ${error.message}`)}
  }
});
$('itamCancel').onclick=()=>$('itamDlg').close();
$('new').onclick=()=>open_();
function itamError(error){alert(`Não foi possível carregar os dados: ${error.message}`)}
window.startApp();

function itamOpenAssign(asset) {
  ITAM.activeAsset=asset;
  const content=`<div class="itam-form-grid">
    ${itamField('Colaborador *','assignName')}
    ${itamField('E-mail','assignEmail','','email')}
    ${me.role==='admin'?itamLocalField('Localidade','assignLocation',asset.location):''}
    ${itamTextArea('Observações','assignNotes','')}
    <div class="itam-field full"><label for="assignSignature">Assinatura digital (opcional)</label><canvas id="assignSignature" class="itam-signature" width="800" height="260" aria-label="Área para desenhar assinatura"></canvas><button type="button" id="clearSignature">Limpar assinatura</button></div>
  </div>`;
  itamModal(`Entregar ${asset.patrimonio||asset.model}`,content,{saveLabel:'Confirmar entrega'});
  const canvas=$('assignSignature'),context=canvas.getContext('2d');
  context.lineWidth=4;context.lineCap='round';context.strokeStyle='#14232a';
  let drawing=false,drawn=false;
  const point=event=>{const box=canvas.getBoundingClientRect();return{x:(event.clientX-box.left)*canvas.width/box.width,y:(event.clientY-box.top)*canvas.height/box.height}};
  canvas.onpointerdown=event=>{drawing=true;drawn=true;canvas.setPointerCapture(event.pointerId);const p=point(event);context.beginPath();context.moveTo(p.x,p.y)};
  canvas.onpointermove=event=>{if(!drawing)return;const p=point(event);context.lineTo(p.x,p.y);context.stroke()};
  canvas.onpointerup=()=>{drawing=false};
  canvas.onpointercancel=()=>{drawing=false};
  $('clearSignature').onclick=()=>{context.clearRect(0,0,canvas.width,canvas.height);drawn=false};
  $('itamSave').onclick=async()=>{
    const holder=$('assignName').value.trim();
    if(!holder){$('assignName').focus();toast('Informe o nome do colaborador');return}
    try {
      const body={holder_name:holder,holder_email:$('assignEmail').value,notes:$('assignNotes').value,version:asset.version,
        location:me.role==='admin'?$('assignLocation').value:asset.location,signature:drawn?canvas.toDataURL('image/png'):''};
      const result=await api('POST',`/api/assets/${encodeURIComponent(asset.id)}/assign`,body);
      $('itamDlg').close();await Promise.all([loadItamAssets(ITAM.assets.page),loadItamDashboard()]);
      const link=document.createElement('a');link.href=result.termUrl;link.target='_blank';link.rel='noopener';link.click();toast('Entrega registrada e termo gerado');
    } catch(error) { alert(`Não foi possível registrar a entrega: ${error.message}`); }
  };
}

async function itamReturnAsset(asset) {
  const note=prompt(`Observação da devolução de ${asset.patrimonio||asset.model}:`,'');
  if(note===null)return;
  try {
    await api('POST',`/api/assets/${encodeURIComponent(asset.id)}/return`,{version:asset.version,note});
    await Promise.all([loadItamAssets(ITAM.assets.page),loadItamDashboard()]);toast('Devolução registrada');
  } catch(error) { alert(`Não foi possível registrar a devolução: ${error.message}`); }
}

async function itamChangeAssetStatus(asset) {
  const available=[['available','Disponível'],['reserved','Reservado']];
  if(me.role==='admin')available.push(['lost','Perdido'],['retired','Baixado']);
  const status=prompt(`Novo status (${available.map(([,label])=>label).join(', ')}):`,ITAM_STATUSES[asset.status]||'Disponível');
  if(status===null)return;
  const selected=available.find(([,label])=>label.toLocaleLowerCase('pt-BR')===status.trim().toLocaleLowerCase('pt-BR')||label===status);
  if(!selected){alert('Informe um status válido.');return}
  const note=prompt('Observação da movimentação (opcional):','')||'';
  try {
    await api('POST',`/api/assets/${encodeURIComponent(asset.id)}/status`,{version:asset.version,status:selected[0],note});
    await Promise.all([loadItamAssets(ITAM.assets.page),loadItamDashboard()]);toast('Status atualizado');
  } catch(error) { alert(`Não foi possível alterar o status: ${error.message}`); }
}

function itamShowHistory(history) {
  const asset=history.asset;
  const movements=history.movements.map(item=>`<div class="itam-activity"><b>${e(item.note||item.movement_type)}</b>
    <small>${e(itamDateTime(item.occurred_at))} · ${e(item.actor_name)} · ${e(ITAM_STATUSES[item.from_status]||'—')} → ${e(ITAM_STATUSES[item.to_status]||'—')}</small></div>`).join('');
  const assignments=history.assignments.map(item=>`<div class="itam-activity"><b>${e(item.holder_name)} · ${e(item.status==='active'?'Entrega ativa':'Devolvida')}</b>
    <small>${e(itamDateTime(item.delivered_at))}${item.returned_at?` · Devolução ${e(itamDateTime(item.returned_at))}`:''} · ${e(item.location)}</small>
    <button type="button" data-term="${e(item.id)}">Termo PDF</button></div>`).join('');
  const tickets=history.tickets.map(item=>`<div class="itam-activity"><b>${e(item.title)}</b><small>${e(ITAM_TICKET_STATUSES[item.status]||item.status)} · ${e(itamDateTime(item.opened_at))}</small></div>`).join('');
  itamModal(`Histórico · ${asset.patrimonio||asset.model}`,`<div class="itam-card"><p><b>${e(ITAM_CATEGORIES[asset.category]||asset.category)} ${e(asset.manufacturer)} ${e(asset.model)}</b><br><span class="itam-muted">Série ${e(asset.serial_number||'—')} · ${e(asset.location)} · ${e(ITAM_STATUSES[asset.status]||asset.status)}</span></p>
    <h3>Movimentações</h3>${movements||'<p class="itam-muted">Nenhuma movimentação.</p>'}
    <h3>Atribuições</h3>${assignments||'<p class="itam-muted">Nenhuma entrega registrada.</p>'}
    <h3>Manutenções</h3>${tickets||'<p class="itam-muted">Nenhum chamado vinculado.</p>'}</div>`,{save:false});
}

async function itamOpenHistory(id) {
  try { const history=await api('GET',`/api/assets/${encodeURIComponent(id)}/history`);itamShowHistory(history); }
  catch(error) { alert(`Não foi possível carregar o histórico: ${error.message}`); }
}

function itamTicketFields(ticket=null,assetId='') {
  const assets=ITAM.assets.items.filter(item=>!['retired','lost','maintenance'].includes(item.status));
  const assetOptions=[['','Sem ativo vinculado'],...assets.map(item=>[item.id,`${item.patrimonio||item.model} · ${ITAM_STATUSES[item.status]||item.status}`])];
  const priorities=Object.entries(ITAM_PRIORITIES),statuses=ticket?Object.entries(ITAM_TICKET_STATUSES):[['open',ITAM_TICKET_STATUSES.open]];
  const editableStatuses=ticket&&['completed','cancelled'].includes(ticket.status)?statuses.filter(([key])=>key===ticket.status):statuses;
  const fields=`<div class="itam-form-grid">
    ${itamField('Título *','ticketTitle',ticket?.title||'')}
    ${itamSelect('Ativo','ticketAsset',assetOptions,ticket?.asset_id||assetId)}
    ${itamSelect('Prioridade','ticketPriority',priorities,ticket?.priority||'normal')}
    ${itamSelect('Status','ticketStatus',editableStatuses,ticket?.status||'open')}
    ${itamField('Técnico responsável','ticketTechnician',ticket?.technician||'')}
    ${itamField('Data prevista','ticketExpected',ticket?.expected_at||'','date')}
    ${ticket?itamTextArea('Descrição','ticketDescription',ticket.description||''):itamTextArea('Descrição','ticketDescription','')}
    ${!ticket&&me.role==='admin'&&!assetId?itamLocalField('Localidade','ticketLocation',selectedLocation!=='*'?selectedLocation:LOCATIONS[0]):''}
  </div>`;
  return fields;
}

async function itamOpenTicket(ticketOrId=null,{create=false,assetId=''}={}) {
  let ticket=ticketOrId;
  if(typeof ticketOrId==='string') {
    ticket=ITAM.tickets.items.find(item=>item.id===ticketOrId)||null;
    if(!ticket) {
      try { const detail=await api('GET',`/api/maintenance/${encodeURIComponent(ticketOrId)}/activities`);ticket=detail.ticket; }
      catch(error) { alert(`Não foi possível localizar o chamado: ${error.message}`);return; }
    }
  }
  let detail={activities:[],attachments:[]};
  if(ticket) {
    try { detail=await api('GET',`/api/maintenance/${encodeURIComponent(ticket.id)}/activities`); }
    catch(error) { alert(`Não foi possível carregar o chamado: ${error.message}`);return; }
    ticket=detail.ticket;
  }
  ITAM.activeTicket=ticket;
  const activityHtml=(detail.activities||[]).map(item=>`<div class="itam-activity"><b>${e(item.note)}</b><small>${e(itamDateTime(item.occurred_at))} · ${e(item.actor_name)}</small></div>`).join('');
  const attachments=(detail.attachments||[]).map(file=>`<div class="itam-activity"><a href="/api/maintenance/${encodeURIComponent(ticket.id)}/attachments/${encodeURIComponent(file.id)}" target="_blank" rel="noopener">${e(file.original_name)}</a><small>${(file.size_bytes/1024).toFixed(0)} KB · ${e(itamDateTime(file.uploaded_at))}</small></div>`).join('');
  const canUpdate=canEdit()&&ticket&&!['completed','cancelled'].includes(ticket.status);
  const content=`${itamTicketFields(ticket,assetId)}
    ${ticket?`<section class="itam-field full"><h3>Atividades</h3>${activityHtml||'<p class="itam-muted">Nenhuma atividade registrada.</p>'}
      <h3>Anexos</h3>${attachments||'<p class="itam-muted">Nenhum anexo.</p>'}
      ${canUpdate?`<div class="itam-form-grid"><div class="itam-field"><label for="ticketActivity">Nova atividade</label><input id="ticketActivity" maxlength="2000"></div><div class="itam-field"><label for="ticketFile">Anexar arquivo (PDF, imagem ou TXT, até 5 MB)</label><input id="ticketFile" type="file" accept=".pdf,.jpg,.jpeg,.png,.webp,.txt"></div></div><div class="itam-actions"><button type="button" data-ticket-activity="1">Registrar atividade</button><button type="button" data-ticket-upload="1">Enviar anexo</button></div>`:''}</section>`:''}`;
  itamModal(ticket?'Detalhes do chamado':'Abrir chamado',content,{save:canEdit(),deleteButton:Boolean(ticket&&me.role==='admin'),saveLabel:ticket?'Atualizar chamado':'Abrir chamado'});
  if(ticket&&me.role==='admin')$('itamDelete').onclick=async()=>{
    if(!confirm('Excluir logicamente este chamado?'))return;
    try{await api('DELETE',`/api/maintenance/${encodeURIComponent(ticket.id)}`);$('itamDlg').close();await Promise.all([loadItamTickets(ITAM.tickets.page),loadItamAssets(ITAM.assets.page),loadItamDashboard()]);toast('Chamado removido')}
    catch(error){alert(`Não foi possível remover o chamado: ${error.message}`)}
  };
  $('itamSave').onclick=async()=>{
    if(!canEdit())return;
    const title=$('ticketTitle').value.trim();
    if(!title){$('ticketTitle').focus();toast('Informe o título do chamado');return}
    const body={title,asset_id:$('ticketAsset').value||null,priority:$('ticketPriority').value,status:$('ticketStatus').value,
      technician:$('ticketTechnician').value,expected_at:$('ticketExpected').value||null,description:$('ticketDescription').value};
    if(ticket)body.version=ticket.version;
    if(!ticket&&me.role==='admin'&&$('ticketLocation'))body.location=$('ticketLocation').value;
    try {
      const result=await api(ticket?'PUT':'POST',ticket?`/api/maintenance/${encodeURIComponent(ticket.id)}`:'/api/maintenance',body);
      $('itamDlg').close();await Promise.all([loadItamTickets(1),loadItamAssets(ITAM.assets.page),loadItamDashboard()]);
      toast(ticket?'Chamado atualizado':'Chamado aberto');
      if(ticket&&result.status!=='completed'&&result.status!=='cancelled')itamOpenTicket(result.id);
    } catch(error) { alert(`Não foi possível salvar o chamado: ${error.message}`); }
  };
}
