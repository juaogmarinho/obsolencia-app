const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');
const express = require('express');
const Database = require('better-sqlite3');
const { mountItamRoutes, migrate } = require('../lib/itam');

const locations = ['Recife', 'Salvador'];
const users = {
  admin: { id: 1, nome: 'Admin', role: 'admin', localidade: 'Recife' },
  operator: { id: 2, nome: 'Operador', role: 'operador', localidade: 'Recife' },
  unassigned: { id: 3, nome: 'Sem local', role: 'operador', localidade: '' },
  viewer: { id: 4, nome: 'Leitor', role: 'visualizador', localidade: 'Recife' }
};

let db, server, baseUrl, temporaryDirectory;

async function request(url, { role = 'admin', method = 'GET', body, headers = {} } = {}) {
  const response = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'x-role': role, ...(body && !(body instanceof FormData) ? { 'Content-Type': 'application/json' } : {}), ...headers },
    body: body == null ? undefined : body instanceof FormData ? body : JSON.stringify(body)
  });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : Buffer.from(await response.arrayBuffer());
  return { response, data };
}

test.beforeEach(async () => {
  temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'controle-ti-itam-'));
  db = new Database(path.join(temporaryDirectory, 'test.db'));
  db.pragma('foreign_keys=ON');
  db.exec(`create table registros(col text not null,id text not null,data text not null,upd integer not null,por text not null,
    localidade text not null default '',uid integer,primary key(col,id));
    create table historico(id integer primary key,quando integer,quem text,acao text,col text,rid text,data text);`);
  const app = express();
  app.use(express.json({ limit: '1mb' }));
  const auth = (req, _res, next) => {
    req.u = users[req.headers['x-role']] || users.admin;
    next();
  };
  const can = (user, level) => (user.role === 'admin' ? 2 : user.role === 'operador' ? 1 : 0) >= level;
  mountItamRoutes(app, { db, auth, can, locations, uploadsDir: path.join(temporaryDirectory, 'uploads') });
  app.use((error, _req, res, _next) => res.status(error.status || 500).json({ erro: error.message }));
  server = app.listen(0);
  await new Promise(resolve => server.once('listening', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.afterEach(async () => {
  await new Promise(resolve => server.close(resolve));
  db.close();
  fs.rmSync(temporaryDirectory, { recursive: true, force: true });
});

async function createAsset(overrides = {}) {
  const { response, data } = await request('/api/assets', {
    method: 'POST',
    body: { model: 'Latitude 7450', category: 'notebook', location: 'Recife', ...overrides }
  });
  assert.equal(response.status, 201);
  return data;
}

test('migration imports legacy stock, delivery and maintenance once without changing old records', async () => {
  const now = Date.now();
  db.prepare('insert into registros(col,id,data,upd,por,localidade,uid) values(?,?,?,?,?,?,?)').run(
    'estoque', 'old-stock', JSON.stringify({ tipo: 'Notebook', mod: 'Latitude', tag: 'PAT-1' }), now, 'Admin', 'Recife', 1
  );
  db.prepare('insert into registros(col,id,data,upd,por,localidade,uid) values(?,?,?,?,?,?,?)').run(
    'entregas', 'old-delivery', JSON.stringify({ tipo: 'Notebook', mod: 'ThinkPad', nome: 'Pessoa', st: 'Entregue' }), now, 'Admin', 'Salvador', 1
  );
  db.prepare('insert into registros(col,id,data,upd,por,localidade,uid) values(?,?,?,?,?,?,?)').run(
    'manutencao', 'old-ticket', JSON.stringify({ equip: 'Notebook', mod: 'Latitude', tag: 'PAT-1', chamado: 'Tela quebrada', autorizada: 'Oficina', st: 'Não resolvido' }), now, 'Admin', 'Recife', 1
  );
  migrate(db, path.join(temporaryDirectory, 'uploads'));
  db.prepare('insert into registros(col,id,data,upd,por,localidade,uid,deleted_at) values(?,?,?,?,?,?,?,?)').run(
    'estoque', 'deleted-stock', JSON.stringify({ tipo: 'Notebook', mod: 'Inativo' }), now, 'Admin', 'Recife', 1, now
  );
  migrate(db, path.join(temporaryDirectory, 'uploads'));
  const assets = db.prepare('select id,status,location from itam_assets order by id').all();
  assert.equal(assets.length, 2);
  assert.deepEqual(assets.map(item => item.status), ['delivered', 'maintenance']);
  assert.equal(db.prepare('select count(*) n from registros').get().n, 4);
  assert.equal(db.prepare('select count(*) n from itam_assignments').get().n, 1);
  assert.equal(db.prepare('select count(*) n from itam_tickets where legacy_ref is not null').get().n, 1);
  const legacyTicket=db.prepare('select status,previous_asset_status from itam_tickets where legacy_ref=?').get('manutencao:old-ticket');
  assert.deepEqual(legacyTicket,{status:'open',previous_asset_status:'available'});
});

test('asset lifecycle uses version checks and records a downloadable responsibility term', async () => {
  const asset = await createAsset({ patrimonio: 'TAG-100', purchase_value: '1234.56' });
  assert.equal(asset.purchase_value, 1234.56);
  const missingBody = await request(`/api/assets/${asset.id}/assign`, { method: 'POST' });
  assert.equal(missingBody.response.status, 409);
  const assigned = await request(`/api/assets/${asset.id}/assign`, {
    method: 'POST',
    body: { version: asset.version, holder_name: 'Colaborador', holder_email: 'user@example.com', location: 'Recife', signature: '' }
  });
  assert.equal(assigned.response.status, 201);
  const conflict = await request(`/api/assets/${asset.id}/assign`, {
    method: 'POST',
    body: { version: asset.version, holder_name: 'Outra pessoa' }
  });
  assert.equal(conflict.response.status, 409);
  const term = await request(assigned.data.termUrl);
  assert.equal(term.response.status, 200);
  assert.equal(term.response.headers.get('content-type'), 'application/pdf');
  assert.equal(term.data.subarray(0, 4).toString(), '%PDF');
  const current = await request(`/api/assets/${asset.id}`);
  const returned = await request(`/api/assets/${asset.id}/return`, {
    method: 'POST', body: { version: current.data.version, note: 'Retorno para estoque' }
  });
  assert.equal(returned.response.status, 200);
  const history = await request(`/api/assets/${asset.id}/history`);
  assert.deepEqual(history.data.movements.map(item => item.movement_type), ['return','delivery','created']);
  assert.equal(history.data.asset.status, 'available');
});

test('completed legacy deliveries generate the requested responsibility term only for their locality', async () => {
  const now = Date.now();
  const delivery = {
    nome: 'Colaborador Teste', matricula: '12345', dep: 'Tecnologia', vp: 'VP 1', uo: 'UO 2',
    empresa: 'Empresa', localizacao: 'Recife', gestor: 'Gestor', cham: 'REQ-100',
    tipo: 'Notebook', mod: 'Latitude', pat: 'PAT-100', hs: true, movimento: 'Admissão',
    st: 'Pendente', dta: '2026-11-17', obs: 'Termo de teste'
  };
  db.prepare('insert into registros(col,id,data,upd,por,localidade,uid) values(?,?,?,?,?,?,?)').run(
    'entregas', 'delivery-100', JSON.stringify(delivery), now, 'Admin', 'Salvador', 1
  );
  const pending = await request('/api/deliveries/delivery-100/term.pdf');
  assert.equal(pending.response.status, 409);

  delivery.st = 'Entregue';
  db.prepare("update registros set data=? where col='entregas' and id=?").run(JSON.stringify(delivery), 'delivery-100');
  const term = await request('/api/deliveries/delivery-100/term.pdf');
  assert.equal(term.response.status, 200);
  assert.equal(term.response.headers.get('content-type'), 'application/pdf');
  assert.equal(term.data.subarray(0, 4).toString(), '%PDF');
  assert.ok(term.data.length > 3000);
  const forbidden = await request('/api/deliveries/delivery-100/term.pdf', { role: 'viewer' });
  assert.equal(forbidden.response.status, 404);
});

test('maintenance closes atomically, enforces terminal states and computes stock reports', async () => {
  const asset = await createAsset({ patrimonio: 'PAT-200' });
  const opened = await request('/api/maintenance', {
    method: 'POST',
    body: { asset_id: asset.id, title: 'Tela quebrada', description: 'Avaliar display', priority: 'high' }
  });
  assert.equal(opened.response.status, 201);
  assert.equal((await request(`/api/assets/${asset.id}`)).data.status, 'maintenance');
  const activity = await request(`/api/maintenance/${opened.data.id}/activities`, {
    method: 'POST', body: { note: 'Equipamento recebido pelo técnico' }
  });
  assert.equal(activity.response.status, 201);
  const ticket = await request(`/api/maintenance/${opened.data.id}/activities`);
  assert.equal(ticket.data.activities.length, 2);
  const completed = await request(`/api/maintenance/${opened.data.id}`, {
    method: 'PUT',
    body: { ...ticket.data.ticket, status: 'completed', priority: 'high', title: opened.data.title }
  });
  assert.equal(completed.response.status, 200);
  assert.equal((await request(`/api/assets/${asset.id}`)).data.status, 'available');
  const reopened = await request(`/api/maintenance/${opened.data.id}`, {
    method: 'PUT', body: { ...completed.data, status: 'open' }
  });
  assert.equal(reopened.response.status, 409);
  const limit = await request('/api/stock-thresholds', {
    method: 'PUT', body: { items: [{ category: 'notebook', minimum: 3 }] }
  });
  assert.equal(limit.response.status, 200);
  const report = await request('/api/reports/stock-critical/csv');
  assert.equal(report.response.status, 200);
  assert.match(report.data.toString('utf8'), /Notebook/);
  assert.match(report.data.toString('utf8'), /3/);
});

test('missing locality cannot broaden scoped list or dashboard queries', async () => {
  for (const url of ['/api/assets', '/api/maintenance', '/api/dashboard', '/api/search?q=test', '/api/reports/assets/csv']) {
    const { response } = await request(url, { role: 'unassigned' });
    assert.equal(response.status, 403, url);
  }
});

test('xlsx, pdf and attachment endpoints return files with access checks', async () => {
  const asset = await createAsset({ patrimonio: 'PAT-300' });
  const xlsx = await request('/api/reports/assets/xlsx');
  assert.equal(xlsx.response.status, 200);
  assert.equal(xlsx.data.subarray(0, 2).toString(), 'PK');
  const pdf = await request('/api/reports/assets/pdf');
  assert.equal(pdf.response.status, 200);
  assert.equal(pdf.data.subarray(0, 4).toString(), '%PDF');

  const ticket = await request('/api/maintenance', { method: 'POST', body: { title: 'Acessório', asset_id: asset.id } });
  assert.equal(ticket.response.status, 201);
  const form = new FormData();
  form.append('file', new Blob(['nota de teste'], { type: 'text/plain' }), 'nota.txt');
  const upload = await request(`/api/maintenance/${ticket.data.id}/attachments`, { method: 'POST', body: form });
  assert.equal(upload.response.status, 201);
  const details = await request(`/api/maintenance/${ticket.data.id}/activities`);
  assert.equal(details.data.attachments.length, 1);
  const download = await request(`/api/maintenance/${ticket.data.id}/attachments/${upload.data.id}`);
  assert.equal(download.data.toString(), 'nota de teste');
  const fakeImage = new FormData();
  fakeImage.append('file', new Blob(['not a png'], { type: 'image/png' }), 'fake.png');
  const rejected = await request(`/api/maintenance/${ticket.data.id}/attachments`, { method: 'POST', body: fakeImage });
  assert.equal(rejected.response.status, 400);
});

test('asset validation rejects impossible dates before saving', async () => {
  const { response } = await request('/api/assets', {
    method: 'POST',
    body: { model: 'Invalid date test', category: 'notebook', location: 'Recife', acquired_at: '2025-02-31' }
  });
  assert.equal(response.status, 400);
});
